<?php echo e($slot); ?>

<?php /**PATH D:\Praktikum DWBI\xampp\htdocs\nurani\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>